class_name GameManager
extends Node2D

var player: Character = null

func _ready() -> void:
	print('=== GameManager listo ===')
	var player_type = CharacterFactory.CharacterType.WARRIOR
	player = CharacterFactory.create(player_type, Vector2(320, 180), 1)

	if player == null:
		push_error("ERROR: No se pudo crear al jugador")
		return

	add_child(player)
	# BUG FIX: asignar global_position DESPUÉS de add_child()
	player.global_position = Vector2(320, 180)
	print("Jugador en posición:", player.global_position)

func _process(delta: float) -> void:
	pass
